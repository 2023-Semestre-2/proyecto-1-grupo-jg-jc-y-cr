package ModuloServiciodeMantenimiento;

import ModulodeClientes.Cliente;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.lang.String;

public class Servicio {
    private static final String FILE_PATH = "servicios.json";
    private static final Scanner scanner = new Scanner(System.in);
    private Cliente cliente;
    private int codigocliente;
    private int codigoServicio;
    private String marcaBicicleta;
    private String descripcionBicicleta;
    private double precio;
    private Date fechaRecibido;
    private Date fechaEntrega;
    private String observaciones;
    private EstadoServicio estado;
    private int codigoCliente;

    public Servicio(int codigo, String marcaBicicleta, String descripcionBicicleta, double precio, Date fechaRecibido, Date fechaEntrega, String observaciones, String estado) {
        this.codigoServicio = codigo;
        this.cliente = new Cliente();
        this.marcaBicicleta = marcaBicicleta;
        this.descripcionBicicleta = descripcionBicicleta;
        this.precio = precio;
        this.fechaRecibido = fechaRecibido;
        this.fechaEntrega = fechaEntrega;
        this.observaciones = observaciones;
        this.estado = EstadoServicio.ABIERTO;
        this.codigoCliente = 0; 
    }

// Constructor privado
    public Servicio() {
        this.codigoServicio = generarSiguienteCodigo(); 
        this.marcaBicicleta = "";
        this.descripcionBicicleta = "";
        this.precio = 0.0;
        this.fechaRecibido = new Date();
        this.fechaEntrega = new Date();
        this.observaciones = "";
        this.estado = EstadoServicio.ABIERTO;
    }   
        
    public enum EstadoServicio {
    ABIERTO, CERRADO;
    }

    
      public int getCodigoCliente() {
    return this.codigoCliente; 
  }

  public void setCodigoCliente(int codigoCliente) {
    this.codigoCliente = codigoCliente;
  }
 
public void asociarCliente(Cliente cliente) {
  this.cliente = cliente;
  this.codigoCliente = cliente.getCodigoCliente(); 

}
  
public String getNombreCliente() {
        return cliente.getNombre();
}
    public int getCodigoServicio() {
        return codigoServicio;
    }

    public String getMarcaBicicleta() {
        return marcaBicicleta;
    }

    public void setCodigoServicio(int codigoCliente) {
        this.codigoServicio = codigoCliente;
    }

    public String getDescripcionBicicleta() {
        return descripcionBicicleta;
    }

    public void setDescripcionBicicleta(String descripcionBicicleta) {
        this.descripcionBicicleta = descripcionBicicleta;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

private static int ultimoCodigo = 0;
  
private int generarSiguienteCodigo() {
  ultimoCodigo++;
  return ultimoCodigo;
}

public void setMarcaBicicleta(String marcaBicicleta) {
  this.marcaBicicleta = removerEspacios(marcaBicicleta); 
}

public void setDescripcion(String descripcionBicicleta) {
  this.descripcionBicicleta = removerEspacios(descripcionBicicleta);
}

private String removerEspacios(String texto) {
  if(texto != null) {
    return texto.trim();
  } else { 
    return null;
  }
}


    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Date getFechaRecibido() {
        return fechaRecibido;
    }

    public void setFechaRecibido(Date fechaRecibido) {
        this.fechaRecibido = fechaRecibido;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

public EstadoServicio getEstado() {
    return estado;
}

public void setEstado(EstadoServicio estado) {
    this.estado = estado;
}

}