    package ModuloFacturacion;

import Modulo_de_Producto.Producto;
import ModuloServiciodeMantenimiento.Servicio;
import ModulodeClientes.Cliente;
import java.util.ArrayList;
import java.util.Date;

public class Factura {

    private int numeroFactura;
    private int codigoCliente;  
    private Date fechaRecibido;
    private String estado;
    private int subtotal;
    private int impuesto;
    private int total;
    private ArrayList<DetalleFactura> detalles;
    
    
      public Factura(int codigoCliente, Date fechaRecibido, String estado, ArrayList<DetalleFactura> detalles) {
        int numeroFacturaActual = 1;
        this.numeroFactura = numeroFacturaActual++;
        this.codigoCliente = codigoCliente;
        this.fechaRecibido = fechaRecibido;
        this.estado = estado;
        this.detalles = detalles;
        calcularSubtotalImpuestoTotal();
    }

    // Constructor para factura sin detalles
    public Factura() {
        int numeroFacturaActual = 1;
        this.numeroFactura = numeroFacturaActual++;
        this.codigoCliente = 0;
        this.fechaRecibido = null; 
        this.estado = "Valido";
        this.subtotal = 0;
        this.impuesto = 0;
        this.total = 0;
        this.detalles = new ArrayList<DetalleFactura>();
    }
    private static int numeroFacturaActual = 1;

    // Función para calcular subtotal, impuesto y total
    private void calcularSubtotalImpuestoTotal() {
        this.subtotal = calcularSubtotal();
        this.impuesto = calcularImpuesto();
        this.total = this.subtotal + this.impuesto;
    }

    // Función para calcular el subtotal
    // Función para calcular el subtotal
    private int calcularSubtotal() {
        int subtotal = 0;
        for (DetalleFactura detalle : detalles) {
            subtotal += detalle.getTotal();
        }
        return subtotal;
    }


    // Función para calcular el impuesto
    private int calcularImpuesto() {
        return (int) Math.round(0.13 * this.subtotal);
    }


    public int getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(int numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    public int getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(int codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public Date getFechaRecibido() {
        return fechaRecibido;
    }

    public void setFechaRecibido(Date fechaRecibido) {
        this.fechaRecibido = fechaRecibido;
    }

    public String getEstado() {
        return estado;
    }

    public int getSubtotal() {
        return subtotal; 
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }

    public int getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(int impuesto) {
        this.impuesto = impuesto;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    
    public ArrayList<DetalleFactura> getDetalles() {
        return detalles;
    }

    public void setDetalles(ArrayList<DetalleFactura> detalles) {
        this.detalles = detalles;
    }
    
    
    public void eliminarDetalle(int codigo) {
        for(DetalleFactura d: this.detalles) {
            if(d.getCodigoArticulo() == codigo) {
                this.detalles.remove(d);
                break;
            }
        }
    }
    public void setEstado(String estado) {
        if ("Valido".equals(estado) || "Anulado".equals(estado)) {
            this.estado = estado;
        } else {
        // Maneja error o lanza una excepción
        }
    }

public void agregarDetalle(DetalleFactura detalle) {
    this.detalles.add(detalle);
    calcularSubtotalImpuestoTotal();
}


    public void buscar(int numeroFactura, Date fecha, String nombreCliente) {
    }

    public void anular() {
        // Mostrar mensaje de confirmación
        
        // Si confirmado:
        this.estado = "Anulado";
        
        // Mostrar mensaje de éxito o error
    }

}