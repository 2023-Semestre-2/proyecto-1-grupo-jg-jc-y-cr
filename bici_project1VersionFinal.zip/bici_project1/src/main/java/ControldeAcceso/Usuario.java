/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ControldeAcceso;

/**
 * Clase que representa un usuario en el sistema.
 * Contiene información como el nombre de usuario y la contraseña.
 * Puede ser utilizado para gestionar la autenticación en el sistema.
 * @author Cesar,Juan y Jimmy
 */
public class Usuario {
    
    private String nombreUsuario; //nombre del usuario
    private String contraseña; //contraseña del usuario
    
    /**
     * Constructor por defecto de la clase Usuario.
     * Inicializa el nombre de usuario y la contraseña como cadenas vacías.
     */
    public Usuario() {
        this.nombreUsuario = "";
        this.contraseña = "";
    }

    
       /**
     * Constructor parametrizado de la clase Usuario.
     * Inicializa el nombre de usuario y la contraseña con los valores proporcionados.
     * @param nombreUsuario El nombre de usuario del usuario.
     * @param contraseña La contraseña del usuario.
     */
    public Usuario(String nombreUsuario, String contraseña) {
        this.nombreUsuario = nombreUsuario;
        this.contraseña = contraseña;
    }
    /**
     * Método para obtener el nombre de usuario.
     * @return El nombre de usuario del usuario.
     */
    public String getNombreUsuario() {
        return nombreUsuario;
    }
    /**
     * Método para establecer el nombre de usuario.
     * @param nombreUsuario El nuevo nombre de usuario a establecer.
     */
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }


    /**
     * Método para obtener la contraseña del usuario.
     * @return La contraseña del usuario.
     */
    public String getContraseña() {
        return contraseña;
    }

    /**
     * Método para establecer la contraseña del usuario.
     * @param contraseña La nueva contraseña a establecer.
     */
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
}
