/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ModuloFacturacion;

import ModuloServiciodeMantenimiento.Servicio;
import Modulo_de_Producto.Producto;
import static Modulo_de_Producto.ProductoGUI.cargarProductos;
import ModulodeClientes.Cliente;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author PC
 */
public class FacturaGUI extends javax.swing.JFrame {

    private ArrayList<Servicio> servicios;
    private ArrayList<Cliente> clientes;
    private ArrayList<Producto> productos;
    private ArrayList<Factura> facturas;
    private ArrayList<JButton> botonesProductos;
    private ArrayList<JButton> botonesClientes;
    private ArrayList<JButton> botonesFacturas;
    private int subtotalActual;
    private int impuestoActual;
    private int totalActual;
    private int precioUnitarioActual;
    private Factura facturaActual;
    private DetalleFactura DetaActual;
    private Producto produActual;
    private Servicio serviActual;
    private Cliente clienteActual;
    private ArrayList<DetalleFactura> detallesActual;
    private int numeroDetalles;

    /**
     * Creates new form FacturaGUI
     */
    public FacturaGUI() {
        initComponents();
        servicios = new ArrayList<>();
        clientes = new ArrayList<>();
        productos = new ArrayList<>();
        facturas = new ArrayList<>();
        detallesActual = new ArrayList<>();
        botonesClientes = new ArrayList<>();
        botonesFacturas = new ArrayList<>();
        botonesProductos = new ArrayList<>();
        clienteActual = new Cliente();
        serviActual = new Servicio();
        produActual = new Producto();
        facturaActual = new Factura();
        cargarClientes();
        clientes = cargarClientes();
        productos = cargarProductos();
        servicios = cargarServicios();
        subtotalActual = 0;
        impuestoActual = 0;
        totalActual = 0;
        precioUnitarioActual = 0;
        crearBotonesClientes();
        crearBotonesArticulos();
        numeroDetalles = 0;
        crearBotonesFacturas();
    }

    public int getNumeroDetalles() {
        return numeroDetalles;
    }

    public void setNumeroDetalles(int numeroDetalles) {
        this.numeroDetalles = numeroDetalles;
    }
    
    
    //metodos Json
    
    

    public ArrayList<Servicio> cargarServicios() {
        ArrayList<Servicio> listaservicios = new ArrayList<>();
        try (Reader reader = new FileReader("Servicios.json")) {
            Gson gson = new Gson();
            Servicio[] serviciosArray = gson.fromJson(reader, Servicio[].class);
            if (serviciosArray != null) {
                listaservicios.addAll(Arrays.asList(serviciosArray));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listaservicios;
    }
    public static ArrayList<Producto> cargarProductos() {
        ArrayList<Producto> listaProductos = new ArrayList<>();
        try (Reader reader = new FileReader("Productos.json")) {
            Gson gson = new Gson();
            Producto[] productosArray = gson.fromJson(reader, Producto[].class);
            if (productosArray != null) {
                listaProductos.addAll(Arrays.asList(productosArray));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listaProductos;
    }
    public static ArrayList<Cliente> cargarClientes() {

        ArrayList<Cliente> listaClientes = new ArrayList<>();

        try (Reader reader = new FileReader("clientes.json")) {

            Gson gson = new Gson();
            Cliente[] clientesArray = gson.fromJson(reader, Cliente[].class);

            if (clientesArray != null) {
                listaClientes.addAll(Arrays.asList(clientesArray));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return listaClientes;
    }
    
    
    
    
    //ver si esta creado el objeto
    
    public int estaElObjeto(String nombre){
        String nombreFix = nombre.trim();
        int value = -1;
        for(Cliente clie : clientes){
            String posCode =""+clie.getCodigo();
            if(clie.getNombre().equals(nombreFix) || posCode.equals(nombreFix)){
                return clientes.indexOf(clie);
            }
        }
        return value;
    }
    
    public int estaElProducto(String nombre){
        String nombreFix = nombre.trim();
        int value = -1;
        for(Producto pro : productos){
            String posCode =""+pro.getCodigo();
            if(pro.getNombre().equals(nombreFix) || posCode.equals(nombreFix)){
                return productos.indexOf(pro);
            }
        }
        return value;
    }
    
    public int estaLaFactura(String nombre){
        String nombreFix = nombre.trim();
        int value = -1;
        for(Factura pro : facturas){
            String posCode =""+pro.getNumeroFactura();
            String fecha = formatDate(pro.getFechaRecibido());
            int indexCliente = estaElObjeto(""+pro.getCodigoCliente());
            String nombrecliente = clientes.get(indexCliente).getNombre();
                    
            if(posCode.equals(nombreFix) || fecha.equals(nombreFix) || nombrecliente.equals(nombreFix)){
                return facturas.indexOf(pro);
            }
        }
        return value;
    }
    
    
    public int estaElServicio(String parametro) {
        parametro = parametro.trim();

        try {
            // Intenta interpretar el parámetro como un número (código de servicio)
            int codigoServicio = Integer.parseInt(parametro);

            // Realiza la búsqueda por código de servicio
            for (int i = 0; i < servicios.size(); i++) {
                Servicio servi = servicios.get(i);
                if (servi.getCodigoServicio() == codigoServicio) {
                    return i; // Devuelve el índice del servicio encontrado
                }
            }
        } catch (NumberFormatException e) {
            // Si no se puede convertir a número, realiza la búsqueda por nombre del cliente
            for (int i = 0; i < servicios.size(); i++) {
                Servicio servi = servicios.get(i);
                if (servi.getNombreCliente().equalsIgnoreCase(parametro)) {
                    return i; // Devuelve el índice del servicio encontrado
                }
            }
        }

        return -1; // Si no se encuentra el servicio, devuelve -1
    }
    
    //metodos creacion de botones 
   
    
        private void crearBotonesClientes() {
        for (Cliente clie : clientes) {
            JButton boton = new JButton(clie.getCodigo() + "  " + clie.getNombre() + " " + clie.getApellidos() + clie.getProvincia());
            boton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String txtBuscar = clie.getNombre();
                    int indexCliente = estaElObjeto(txtBuscar);
                    jLabel26.setText(clientes.get(indexCliente).getNombre());
                    jLabel28.setText(clientes.get(indexCliente).getApellidos());
                    clienteActual = clientes.get(indexCliente);
                    
                }
            });

            botonesClientes.add(boton);
        }

        for (JButton boton : botonesClientes) {
            ClientesVisual.add(boton);
        }
        botonesClientes.clear();
    }
        private void crearBotonesArticulos() {
        for (Servicio clie : servicios) {
            JButton boton = new JButton(""+clie.getCodigoServicio());
            boton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int txtBuscar = clie.getCodigoServicio();
                    int indexCliente = estaElServicio(""+txtBuscar);
                    jLabel16.setText(servicios.get(indexCliente).getEstado());
                    jLabel32.setText(servicios.get(indexCliente).getDescripcionBicicleta());
                    jLabel30.setText(Integer.toString(servicios.get(indexCliente).getCodigoServicio()));
                    subtotalActual = (servicios.get(indexCliente).getPrecio());
                    jLabel20.setText(""+subtotalActual);
                    impuestoActual = calcularImpuesto((servicios.get(indexCliente).getPrecio()));
                    jLabel2.setText(""+subtotalActual);
   
                    jLabel24.setText(""+impuestoActual);
                    totalActual = subtotalActual + impuestoActual;
                    jLabel22.setText(""+totalActual);
                    serviActual = servicios.get(indexCliente);
                }
            });

            botonesProductos.add(boton);
        }
        for (Producto clie : productos) {
            JButton boton = new JButton(clie.getCodigo() + "  " + clie.getNombre());
            boton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String txtBuscar = clie.getNombre();
                    int indexCliente = estaElProducto(txtBuscar);
                    jLabel16.setText("es un articulo nuevo");
                    jLabel32.setText(productos.get(indexCliente).getNombre());
                    jLabel30.setText(Integer.toString(productos.get(indexCliente).getCodigo()));
                    subtotalActual = (productos.get(indexCliente).getPrecio());
                    jLabel20.setText(""+subtotalActual);
                    impuestoActual = calcularImpuesto((productos.get(indexCliente).getPrecio()));
                    jLabel24.setText(""+impuestoActual);
                    precioUnitarioActual = (productos.get(indexCliente).getPrecio())/productos.get(indexCliente).getCantidad();
                    jLabel2.setText(""+precioUnitarioActual);
                    totalActual = subtotalActual + impuestoActual;
                    jLabel22.setText(""+totalActual);
                    jLabel6.setText(""+productos.get(indexCliente).getCantidad());
                    produActual = productos.get(indexCliente);
                }
            });

            botonesProductos.add(boton);
        }

        for (JButton boton : botonesProductos) {
            ProduServi.add(boton);
        }
        botonesProductos.clear();
    }
        
        // Función para calcular el impuesto
    private int calcularImpuesto(int precio) {
        return (int) Math.round(0.13 * precio);
    }
     private void crearBotonesFacturas() {
    for (Factura factu : facturas) {
        JButton boton = new JButton();
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String txtBuscar = ""+factu.getNumeroFactura();
                int indexProducto = estaLaFactura(txtBuscar);
                facturaActual = facturas.get(indexProducto);
                int indexCliente = estaElObjeto(""+facturas.get(indexProducto).getCodigoCliente());
                clienteActual = clientes.get(indexCliente);
                jLabel16.setText(facturaActual.getEstado());
                subtotalActual = (facturaActual.getSubtotal());
                jLabel20.setText("" + subtotalActual);
                impuestoActual = facturaActual.getImpuesto();
                jLabel2.setText("" + subtotalActual);
                jLabel24.setText("" + impuestoActual);
                totalActual = subtotalActual + impuestoActual;
                jLabel22.setText("" + totalActual);
                jLabel26.setText(clientes.get(indexCliente).getNombre());
                jLabel28.setText(clientes.get(indexCliente).getApellidos());
                clienteActual = clientes.get(indexCliente);
                jLabel6.setText("" + productos.get(indexCliente).getCantidad());
                Date fecha = facturaActual.getFechaRecibido();
                FeechaTxt.setText(formatDate(fecha));            }  
        });

        botonesFacturas.add(boton);
    }

    for (JButton boton : botonesFacturas) {
        jPanel1.add(boton);
    }
    botonesProductos.clear();
}
    
        
        

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        ProduServi = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();
        jLabel16 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        btnBuscar = new javax.swing.JButton();
        Txt_Buscar = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        ClientesVisual = new javax.swing.JPanel();
        FeechaTxt = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Precio Unitario");

        jLabel2.setText("jLabel2");

        jLabel19.setText("Subtotal");

        jLabel3.setText("Total");

        jLabel20.setText("Inserte Subtotal");

        jLabel5.setText("jLabel5");

        jButton2.setText("Agregar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel22.setText("Inserte Total");

        jButton3.setText("Anular");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel23.setText("Total");

        jLabel25.setText("Cliente");

        jLabel26.setText("insertar Cliente");

        jLabel27.setText("Codigo Cliente");

        jLabel28.setText("insertar codigo Cliente");

        jLabel29.setText("Detalles");

        jLabel30.setText("insertar codigo articulo");

        jLabel31.setText("Codigo Articulo");

        jLabel32.setText("insertar articulo");

        jLabel33.setText("Articulo");

        ProduServi.setLayout(new java.awt.GridBagLayout());
        jScrollPane3.setViewportView(ProduServi);

        jLabel14.setText("Seleccionar Cliente");

        jLabel34.setText("Cantidad");

        jLabel15.setText("Estado");

        jLabel16.setText("Insertar Estado");

        jLabel35.setText("Articulos");

        jLabel17.setText("Fecha de Recibido");

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        Txt_Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Txt_BuscarActionPerformed(evt);
            }
        });

        jButton1.setText("Atras");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        ClientesVisual.setLayout(new java.awt.GridBagLayout());
        jScrollPane2.setViewportView(ClientesVisual);

        FeechaTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FeechaTxtActionPerformed(evt);
            }
        });

        jLabel24.setText("Inserte impuesto");

        jLabel21.setText("Impuesto");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jLabel4.setText("Cantidad Actual");

        jLabel6.setText("jLabel6");

        jButton4.setText("Agregar Detalle");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel7.setText("Numero de detalles:");

        jLabel8.setText("0");

        jPanel1.setLayout(new java.awt.GridBagLayout());
        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Txt_Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscar))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel19))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel17)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(FeechaTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 142, Short.MAX_VALUE)
                                        .addGap(185, 185, 185))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(109, 109, 109)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel23)
                                            .addComponent(jLabel22)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel25)
                                            .addComponent(jLabel26))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel27)
                                            .addComponent(jLabel28)))
                                    .addComponent(jLabel35)
                                    .addComponent(jLabel3)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel29)
                                            .addComponent(jLabel20))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel33)
                                            .addComponent(jLabel32)
                                            .addComponent(jLabel34)
                                            .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel30)
                                                    .addComponent(jLabel31)))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(2, 2, 2)
                                                .addComponent(jLabel6))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(139, 139, 139)
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel1)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel8))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton2)
                                .addGap(81, 81, 81)
                                .addComponent(jButton3))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(Txt_Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel25)
                                .addGap(5, 5, 5)
                                .addComponent(jLabel26))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel27)
                                .addGap(5, 5, 5)
                                .addComponent(jLabel28)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(jLabel17))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(FeechaTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel23))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel22)))
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel29)
                        .addGap(31, 31, 31)
                        .addComponent(jLabel35)
                        .addGap(5, 5, 5)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel33)
                                .addGap(5, 5, 5)
                                .addComponent(jLabel32))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel31)
                                .addGap(5, 5, 5)
                                .addComponent(jLabel30)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel34)
                                .addComponent(jLabel4))
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 506, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton2)
                        .addComponent(jButton3))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton4)
                        .addComponent(jLabel7)
                        .addComponent(jLabel8)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            // TODO add your handling code here:
            
            facturaActual.setCodigoCliente(clienteActual.getCodigo());
            clienteActual = new Cliente();
            facturaActual.setDetalles(detallesActual);
            detallesActual = new ArrayList<>();
            facturaActual.setEstado(facturaActual.getEstado());
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date fechaFact = dateFormat.parse(FeechaTxt.getText());
            
            facturaActual.setFechaRecibido(fechaFact);
            facturaActual.setImpuesto(impuestoActual);
            impuestoActual = 0;
            facturaActual.setNumeroFactura(numeroDetalles);
            facturaActual.setSubtotal(subtotalActual);
            subtotalActual = 0;
            facturaActual.setTotal(totalActual);
            totalActual = 0;
            
            facturas.add(facturaActual);
            
            facturaActual = new Factura();
            for (Factura factu: facturas) {
                System.out.println(factu.getNumeroFactura()+" "+factu.getTotal()+" "+factu.getCodigoCliente());
            }
        } catch (ParseException ex) {
            Logger.getLogger(FacturaGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        crearBotonesFacturas();
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        int respuesta = JOptionPane.showConfirmDialog(null, "estas seguro de anular la factura?", "Confirmación", JOptionPane.YES_NO_OPTION);
        String txtBuscar = ""+facturaActual.getNumeroFactura();
        int indexProducto = estaLaFactura(txtBuscar);
        if (respuesta == JOptionPane.YES_OPTION){
            facturas.remove(indexProducto);
        }
        for (Factura factu : facturas) {
            System.out.println(factu.getNumeroFactura() + " " + factu.getTotal() + " " + factu.getCodigoCliente());
        }
        crearBotonesFacturas();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        // TODO add your handling code here:
        FeechaTxt.setText(formatDate(facturaActual.getFechaRecibido()));
        String txtBuscar = Txt_Buscar.getText();
        int indexProducto = estaLaFactura(txtBuscar);
        facturaActual = facturas.get(indexProducto);
        int indexCliente = estaElObjeto("" + facturas.get(indexProducto).getCodigoCliente());
        clienteActual = clientes.get(indexCliente);
        jLabel16.setText(facturaActual.getEstado());
        subtotalActual = (facturaActual.getSubtotal());
        jLabel20.setText("" + subtotalActual);
        impuestoActual = facturaActual.getImpuesto();
        jLabel2.setText("" + subtotalActual);
        jLabel24.setText("" + impuestoActual);
        totalActual = subtotalActual + impuestoActual;
        jLabel22.setText("" + totalActual);
        jLabel26.setText(clientes.get(indexCliente).getNombre());
        jLabel28.setText(clientes.get(indexCliente).getApellidos());
        clienteActual = clientes.get(indexCliente);
        jLabel6.setText("" + productos.get(indexCliente).getCantidad());
        Date fecha = facturaActual.getFechaRecibido();
        FeechaTxt.setText(formatDate(fecha));  
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        DetalleFactura detalle = new DetalleFactura();
        if (produActual.getCodigo() >= 1 && serviActual.getCodigoServicio() != 0){
            detalle.setCantidad(produActual.getCantidad());
            detalle.setCodigoArticulo(produActual.getCodigo());
            detalle.setFactura(facturaActual);
            detalle.setNumeroFactura(facturaActual.getNumeroFactura());
            detalle.setPrecioUnitario(precioUnitarioActual);
            detalle.setProducto(produActual);
            detalle.setTotal(totalActual);
            setNumeroDetalles(numeroDetalles+1);
            jLabel8.setText(""+numeroDetalles);
        }
        else{
            detalle.setCantidad(1);
            detalle.setCodigoArticulo(serviActual.getCodigoServicio());
            detalle.setFactura(facturaActual);
            detalle.setNumeroFactura(facturaActual.getNumeroFactura());
            detalle.setPrecioUnitario(precioUnitarioActual);
            detalle.setTotal(totalActual);
            
        }
        
        detallesActual = facturaActual.getDetalles();
        detallesActual.add(detalle);
        for (DetalleFactura servicio : detallesActual) {
            System.out.println("detalle Creado con exito: "+servicio.getProducto()+" "+servicio.getPrecioUnitario());
        }
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void FeechaTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FeechaTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FeechaTxtActionPerformed

    private void Txt_BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Txt_BuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Txt_BuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FacturaGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FacturaGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FacturaGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FacturaGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FacturaGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ClientesVisual;
    private javax.swing.JTextField FeechaTxt;
    private javax.swing.JPanel ProduServi;
    private javax.swing.JTextField Txt_Buscar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSpinner jSpinner1;
    // End of variables declaration//GEN-END:variables
private String formatDate(Date fecha) {
  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
  return dateFormat.format(fecha);
}
}
