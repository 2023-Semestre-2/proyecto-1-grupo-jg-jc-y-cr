package ModuloFacturacion;
import ModuloServiciodeMantenimiento.Servicio;
import Modulo_de_Producto.Producto;
import java.util.Objects;

class DetalleFactura {
    private Producto producto;
    private Factura factura;
    private int codigoArticulo;
    private int numeroFactura;  
    private int cantidad;
    private int precioUnitario;
    private int total;

    public DetalleFactura(Producto producto, Factura factura, int codigoArticulo, int numeroFactura, int cantidad, int precioUnitario, int total) {
        this.producto = producto;
        this.codigoArticulo = codigoArticulo;
        this.numeroFactura = numeroFactura;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.total = (int) calcularTotal();
    }    

    public DetalleFactura() {
        setCantidad(0);
        setCodigoArticulo(0);
        setNumeroFactura(0);
        setPrecioUnitario(0);
        setProducto(null);
        setTotal(0);
    }
    

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Factura getFactura() {
        return factura;
    }

    public void setFactura(Factura factura) {
        this.factura = factura;
    }
    // Getters y setters
    private double calcularTotal() {
        return cantidad * precioUnitario;
    }
    public void actualizarTotal() {
        this.total = (int) calcularTotal();
    }
    public int getCodigoArticulo() {
        return codigoArticulo;
    }

    public void setCodigoArticulo(int codigoArticulo) {
        this.codigoArticulo = codigoArticulo;
    }

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(int numeroFactura) {
        this.numeroFactura = numeroFactura;
    }


    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(int precioUnitario) {
        this.precioUnitario =  precioUnitario;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        DetalleFactura that = (DetalleFactura) obj;
        return codigoArticulo == that.codigoArticulo &&
            cantidad == that.cantidad &&
            Double.compare(that.precioUnitario, precioUnitario) == 0 &&
            Double.compare(that.total, total) == 0;
}

@Override
public int hashCode() {
    return Objects.hash(codigoArticulo, cantidad, precioUnitario, total);
}


}