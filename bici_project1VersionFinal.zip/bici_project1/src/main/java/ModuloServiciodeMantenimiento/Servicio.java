package ModuloServiciodeMantenimiento;

import ModulodeClientes.Cliente;
import java.util.Date;

/**
 * Representa un servicio de mantenimiento para bicicletas.
 */
public class Servicio {
    private Cliente cliente;
    private int codigocliente;
    private int codigoServicio;
    private String marcaBicicleta;
    private String descripcionBicicleta;
    private int precio;
    private Date fechaRecibido;
    private Date fechaEntrega;
    private String observaciones;
    private String estado;
    private int codigoCliente;
    /**
     * Constructor por defecto de la clase Servicio.
     * Inicializa los atributos con valores predeterminados.
     */
    public Servicio() {
        this.codigoServicio = 1;
        this.marcaBicicleta = "";
        this.descripcionBicicleta = "";
        this.precio = 0;
        this.fechaRecibido = new Date();
        this.fechaEntrega = new Date();
        this.observaciones = "";
        this.estado = "";
    }

    /**
     * Obtiene el código del cliente asociado al servicio.
     *
     * @return El código del cliente asociado al servicio.
     */
    public int getCodigoCliente() {
        return this.codigoCliente;
    }

    /**
     * Establece el código del cliente asociado al servicio.
     *
     * @param codigoCliente El código del cliente a establecer.
     */
    public void setCodigoCliente(int codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    /**
     * Asocia un cliente al servicio y actualiza el código del cliente asociado.
     *
     * @param cliente El cliente a asociar al servicio.
     */
    public void asociarCliente(Cliente cliente) {
        this.cliente = cliente;
        this.codigoCliente = cliente.getCodigo();
    }

    /**
     * Obtiene el nombre del cliente asociado al servicio.
     *
     * @return El nombre del cliente asociado al servicio.
     */
    public String getNombreCliente() {
        return cliente.getNombre();
    }

    /**
     * Obtiene el código del servicio.
     *
     * @return El código del servicio.
     */
    public int getCodigoServicio() {
        return codigoServicio;
    }

    /**
     * Obtiene la marca de la bicicleta asociada al servicio.
     *
     * @return La marca de la bicicleta asociada al servicio.
     */
    public String getMarcaBicicleta() {
        return marcaBicicleta;
    }

    /**
     * Establece el código del servicio.
     *
     * @param codigoCliente El código del servicio a establecer.
     */
    public void setCodigoServicio(int codigoCliente) {
        this.codigoServicio = codigoCliente;
    }

    /**
     * Obtiene la descripción de la bicicleta asociada al servicio.
     *
     * @return La descripción de la bicicleta asociada al servicio.
     */
    public String getDescripcionBicicleta() {
        return descripcionBicicleta;
    }

    /**
     * Establece la descripción de la bicicleta asociada al servicio.
     *
     * @param descripcionBicicleta La descripción de la bicicleta a establecer.
     */
    public void setDescripcionBicicleta(String descripcionBicicleta) {
        this.descripcionBicicleta = descripcionBicicleta;
    }

    /**
     * Obtiene las observaciones del servicio.
     *
     * @return Las observaciones del servicio.
     */
    public String getObservaciones() {
        return observaciones;
    }

    /**
     * Establece las observaciones del servicio.
     *
     * @param observaciones Las observaciones a establecer.
     */
    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    /**
     * Obtiene el precio del servicio.
     *
     * @return El precio del servicio.
     */
    public int getPrecio() {
        return precio;
    }

    /**
     * Establece el precio del servicio.
     *
     * @param precio El precio del servicio a establecer.
     */
    public void setPrecio(int precio) {
        this.precio = precio;
    }

    /**
     * Obtiene la fecha en que se recibió el servicio.
     *
     * @return La fecha de recepción del servicio.
     */
    public Date getFechaRecibido() {
        return fechaRecibido;
    }

    /**
     * Establece la fecha en que se recibió el servicio.
     *
     * @param fechaRecibido La fecha de recepción del servicio.
     */
    public void setFechaRecibido(Date fechaRecibido) {
        this.fechaRecibido = fechaRecibido;
    }

    /**
     * Obtiene la fecha estimada de entrega del servicio.
     *
     * @return La fecha estimada de entrega del servicio.
     */
    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    /**
     * Establece la fecha estimada de entrega del servicio.
     *
     * @param fechaEntrega La fecha estimada de entrega del servicio.
     */
    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    /**
     * Obtiene el estado del servicio.
     *
     * @return El estado del servicio.
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Establece el estado del servicio.
     *
     * @param estado El estado del servicio a establecer.
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    // Métodos privados

    /**
     * Establece la marca de la bicicleta asociada al servicio.
     * Elimina espacios en blanco al principio y al final del texto.
     *
     * @param marcaBicicleta La marca de la bicicleta a establecer.
     */
    public void setMarcaBicicleta(String marcaBicicleta) {
        this.marcaBicicleta = removerEspacios(marcaBicicleta);
    }

    /**
     * Establece la descripción de la bicicleta asociada al servicio.
     * Elimina espacios en blanco al principio y al final del texto.
     *
     * @param descripcionBicicleta La descripción de la bicicleta a establecer.
     */
    public void setDescripcion(String descripcionBicicleta) {
        this.descripcionBicicleta = removerEspacios(descripcionBicicleta);
    }

    /**
     * Elimina espacios en blanco al principio y al final del texto.
     *
     * @param texto El texto del cual se eliminarán los espacios.
     * @return El texto sin espacios en blanco al principio y al final.
     */
    private String removerEspacios(String texto) {
        if (texto != null) {
            return texto.trim();
        } else {
            return null;
        }
    }
}

