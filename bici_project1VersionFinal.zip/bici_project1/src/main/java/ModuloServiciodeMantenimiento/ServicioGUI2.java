package ModuloServiciodeMantenimiento;

import ControldeAcceso.Pantalla_Principal;
import ModuloFacturacion.FacturaGUI;
import ModulodeClientes.Cliente;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.awt.Component;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import java.lang.String;
import javax.swing.JFrame;

/**
 * Representa un servicio de mantenimiento para bicicletas.
 */
public class ServicioGUI2 extends javax.swing.JFrame {
    private ArrayList<Servicio> servicios;
    private Servicio serviActual;
    private ArrayList<JButton> botonesServicios;
    private Object panelServicios;
    private ArrayList<Cliente> clientes;

    /**
     * Constructor por defecto de la clase Servicio.
     * Inicializa los atributos con valores predeterminados.
     */

    public ServicioGUI2() {
        initComponents();
        clientes = cargarClientes();
        serviActual = new Servicio();
        servicios = cargarServicios();
        this.botonesServicios = new ArrayList<>();
        crearBotonesServicios();
    }
        /**
     * Obtiene la lista de servicios.
     *
     * @return La lista de servicios.
     */
        public ArrayList<Servicio> getServicios() {
        return servicios;
    }
    /**
     * Establece la lista de servicios.
     *
     * @param servicios La lista de servicios a establecer.
     */
    public void setServicios(ArrayList<Servicio> servicios) {
        this.servicios = servicios;
    }
    /**
     * Obtiene el servicio actual.
     *
     * @return El servicio actual.
     */
    public Servicio getServiActual() {
        return serviActual;
    }
    /**
     * Establece el servicio actual.
     *
     * @param serviActual El servicio actual a establecer.
     */
    public void setServiActual(Servicio serviActual) {
        this.serviActual = serviActual;
    }
    /**
     * Asigna un nuevo código para un servicio.
     *
     * @return El nuevo código asignado.
     */
    private int asignarCodigo(){
        int codigoAsignado = 1;
        for (Servicio servicio : servicios) {
            int code = servicio.getCodigoServicio();
            codigoAsignado = code;
        }
        return codigoAsignado+1;
    }
    /**
     * Verifica si un servicio existe en la lista de servicios.
     *
     * @param parametro El parámetro para buscar el servicio (puede ser código o nombre de cliente).
     * @return El índice del servicio si se encuentra, -1 si no se encuentra.
     */
public int estaElServicio(String parametro) {
    parametro = parametro.trim();

    try {
        // Intenta interpretar el parámetro como un número (código de servicio)
        int codigoServicio = Integer.parseInt(parametro);

        // Realiza la búsqueda por código de servicio
        for (int i = 0; i < servicios.size(); i++) {
            Servicio servi = servicios.get(i);
            if (servi.getCodigoServicio() == codigoServicio) {
                return i; // Devuelve el índice del servicio encontrado
            }
        }
    } catch (NumberFormatException e) {
        // Si no se puede convertir a número, realiza la búsqueda por nombre del cliente
        for (int i = 0; i < servicios.size(); i++) {
            Servicio servi = servicios.get(i);
            if (servi.getNombreCliente().equalsIgnoreCase(parametro)) {
                return i; // Devuelve el índice del servicio encontrado
            }
        }
    }

    return -1; // Si no se encuentra el servicio, devuelve -1
}
public int estaElCliente(String nombre) {
        String nombreFix = nombre.trim();
        int value = -1;
        for(Cliente clie : clientes) {
            String posCode =""+clie.getCodigo();
            if(clie.getNombre().equals(nombreFix) || posCode.equals(nombreFix)) {
                return clientes.indexOf(clie);
            }
        }
        return value;
    }

    // Método para guardar servicios en un archivo JSON

       
    /**
     * Guarda la lista de servicios en un archivo JSON.
     *
     * @param servicios La lista de servicios a guardar.
     */
    public static void guardarServicios(ArrayList<Servicio> servicios) {
        try (Writer writer = new FileWriter("Servicios.json")) {
            Gson gson = new GsonBuilder().create();
            gson.toJson(servicios, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * Carga la lista de servicios desde un archivo JSON.
     *
     * @return La lista de servicios cargada desde el archivo JSON.
     */
    public ArrayList<Servicio> cargarServicios() {
        ArrayList<Servicio> listaservicios = new ArrayList<>();
        try (Reader reader = new FileReader("Servicios.json")) {
            Gson gson = new Gson();
            Servicio[] serviciosArray = gson.fromJson(reader, Servicio[].class);
            if (serviciosArray != null) {
                listaservicios.addAll(Arrays.asList(serviciosArray));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listaservicios;
    }
    
    
    /**
     * Carga la lista de clientes desde un archivo JSON.
     *
     * @return La lista de clientes cargada desde el archivo JSON.
     */
    public static ArrayList<Cliente> cargarClientes() {
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        try (Reader reader = new FileReader("clientes.json")) {
            Gson gson = new Gson();
            Cliente[] clientesArray = gson.fromJson(reader, Cliente[].class);
            if (clientesArray != null) {
                listaClientes.addAll(Arrays.asList(clientesArray));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listaClientes;
    }
    
    
    

    


// Método para eliminar un servicio
    
    /**
     * Elimina un servicio de la lista de servicios.
     *
     * @param parametro El parámetro para buscar el servicio a eliminar.
     */
public void eliminarServicio(String parametro) {
    int indexServicio = estaElServicio(parametro);
    if (indexServicio != -1) {
        servicios.remove(indexServicio);
        guardarServicios(servicios);
        JOptionPane.showMessageDialog(null, "Servicio eliminado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(null, "Servicio no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Método para modificar un servicio

    /**
     * Modifica un servicio de la lista de servicios.
     *
     * @param parametro El parámetro para buscar el servicio a modificar.
     */
public void modificarServicio(String parametro) {
    int indexServicio = estaElServicio(parametro);
    if (indexServicio != -1) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Nueva descripción: ");
        String nuevaDescripcion = scanner.nextLine();
        servicios.get(indexServicio).setDescripcionBicicleta(nuevaDescripcion);

        guardarServicios(servicios);
        JOptionPane.showMessageDialog(null, "Servicio modificado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } else {
        JOptionPane.showMessageDialog(null, "Servicio no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    /**
     * Crea botones para cada servicio y los agrega al panel correspondiente.
     */
private void crearBotonesServicios() {
    for (Servicio servicio : servicios) {
        JButton boton = new JButton(
            servicio.getCodigoServicio() + "  " +
            servicio.getCodigoCliente() + "  " +
            servicio.getMarcaBicicleta() + "  " +
            servicio.getDescripcionBicicleta() + "  " +
            servicio.getEstado()
        );

        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String txtBuscarServicio = ""+servicio.getCodigoServicio();
                int indexServicio = estaElServicio(txtBuscarServicio);
                System.out.println(indexServicio);
                if (indexServicio != -1) {
                    // Obtener el servicio a través del índice
                    Servicio servicioEncontrado = servicios.get(indexServicio);
                    
                    // Mostrar la información en los campos correspondientes
                    TXt_cod_cliente.setText(String.valueOf(servicioEncontrado.getCodigoCliente()));
                    TXt_Marca.setText(servicioEncontrado.getMarcaBicicleta());
                    TXt_Descripcion.setText(servicioEncontrado.getDescripcionBicicleta());
                    TXt_Precio.setText(String.valueOf(servicioEncontrado.getPrecio()));
                    TXt_FechaRecib.setText(formatDate(servicioEncontrado.getFechaRecibido()));
                    TXt_FechaEntre.setText(formatDate(servicioEncontrado.getFechaEntrega()));
                    TXt_Observaciones.setText(servicioEncontrado.getObservaciones());
                    EStado_box.setSelectedItem(servicioEncontrado.getEstado());
                } else {
                    // Realizar acciones si el servicio no se encuentra
                    // Por ejemplo, mostrar un mensaje o limpiar los campos
                    JOptionPane.showMessageDialog(null, "Servicio no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        botonesServicios.add(boton);
    }

    for (JButton boton : botonesServicios) {
        panelServicios2.add(boton);
    }
    botonesServicios.clear();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        TXt_cod_cliente = new javax.swing.JTextField();
        EStado_box = new javax.swing.JComboBox<>();
        ButtBuscar = new javax.swing.JButton();
        TXt_Marca = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelServicios2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        TXt_Precio = new javax.swing.JTextField();
        TXt_para_buscar = new javax.swing.JTextField();
        TXt_FechaEntre = new javax.swing.JTextField();
        bttonCrear = new javax.swing.JButton();
        TXt_FechaRecib = new javax.swing.JTextField();
        bttonEliminar = new javax.swing.JButton();
        TXt_Descripcion = new javax.swing.JTextField();
        bttonModificar = new javax.swing.JButton();
        TXt_Observaciones = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel9.setText("Descripcion de la Bicicleta");

        TXt_cod_cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXt_cod_clienteActionPerformed(evt);
            }
        });

        EStado_box.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Abierto", "Cerrado" }));
        EStado_box.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                EStado_boxComponentAdded(evt);
            }
        });
        EStado_box.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EStado_boxActionPerformed(evt);
            }
        });

        ButtBuscar.setText("Buscar");
        ButtBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtBuscarActionPerformed(evt);
            }
        });

        TXt_Marca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXt_MarcaActionPerformed(evt);
            }
        });

        panelServicios2.setToolTipText("");
        panelServicios2.setLayout(new java.awt.GridLayout(0, 1));
        jScrollPane1.setViewportView(panelServicios2);

        jLabel1.setText("Buscar Servicio");

        TXt_Precio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXt_PrecioActionPerformed(evt);
            }
        });

        TXt_para_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXt_para_buscarActionPerformed(evt);
            }
        });

        TXt_FechaEntre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXt_FechaEntreActionPerformed(evt);
            }
        });

        bttonCrear.setText("Crear");
        bttonCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttonCrearActionPerformed(evt);
            }
        });

        TXt_FechaRecib.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXt_FechaRecibActionPerformed(evt);
            }
        });

        bttonEliminar.setText("Eliminar");
        bttonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttonEliminarActionPerformed(evt);
            }
        });

        TXt_Descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXt_DescripcionActionPerformed(evt);
            }
        });

        bttonModificar.setText("Modificar");
        bttonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttonModificarActionPerformed(evt);
            }
        });

        TXt_Observaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXt_ObservacionesActionPerformed(evt);
            }
        });

        jLabel2.setText("Código del Cliente");

        jLabel6.setText("Fercha Recibido");

        jLabel3.setText("Estado del Servicio");

        jLabel7.setText("Fercha entregado");

        jLabel4.setText("Marca");

        jLabel8.setText("Observaciones");

        jLabel5.setText("Precio");

        jButton1.setText("Atras");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(bttonCrear)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bttonModificar)
                                .addGap(0, 0, 0)
                                .addComponent(bttonEliminar))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4)
                                    .addComponent(TXt_cod_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TXt_FechaRecib, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TXt_Marca, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TXt_Descripcion)
                                    .addComponent(jLabel9))
                                .addGap(67, 67, 67)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(TXt_FechaEntre)
                                    .addComponent(TXt_Precio)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(TXt_Observaciones, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(EStado_box, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(TXt_para_buscar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(ButtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addGap(165, 165, 165)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bttonCrear)
                        .addComponent(bttonModificar)
                        .addComponent(bttonEliminar))
                    .addComponent(ButtBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(TXt_para_buscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TXt_cod_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EStado_box, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TXt_Marca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TXt_Precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TXt_FechaEntre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TXt_FechaRecib, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TXt_Descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TXt_Observaciones))
                        .addGap(51, 51, 51))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addGap(14, 14, 14))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TXt_cod_clienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXt_cod_clienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXt_cod_clienteActionPerformed

    private void EStado_boxComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_EStado_boxComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_EStado_boxComponentAdded

    private void EStado_boxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EStado_boxActionPerformed
        // TODO add your handling code here:
        if (EStado_box.getSelectedItem().equals("Cerrado")) {
            if (!"".equals(TXt_Marca.getText())){
                FacturaGUI p = new FacturaGUI();
                p.setVisible(true);
                dispose();
            }
        }
        
        
    }//GEN-LAST:event_EStado_boxActionPerformed
/**
 * Maneja el evento de búsqueda de un servicio.
 *
 * @param evt El evento de acción asociado a la búsqueda.
 */
    private void ButtBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtBuscarActionPerformed

        String txtBuscar = TXt_para_buscar.getText().trim();
        int indexServicio = estaElServicio(txtBuscar);

        if (indexServicio != -1) {
            // Obtener el servicio a través del índice
            Servicio servicioEncontrado = servicios.get(indexServicio);

            // Mostrar la información en los campos correspondientes
            TXt_cod_cliente.setText(String.valueOf(servicioEncontrado.getCodigoCliente()));
            TXt_Marca.setText(servicioEncontrado.getMarcaBicicleta());
            TXt_Descripcion.setText(servicioEncontrado.getDescripcionBicicleta());
            TXt_Precio.setText(String.valueOf(servicioEncontrado.getPrecio()));
            TXt_FechaRecib.setText(formatDate(servicioEncontrado.getFechaRecibido()));
            TXt_FechaEntre.setText(formatDate(servicioEncontrado.getFechaEntrega()));
            TXt_Observaciones.setText(servicioEncontrado.getObservaciones());
            EStado_box.setSelectedItem(String.valueOf(servicioEncontrado.getEstado()));
        } else {
               JOptionPane.showMessageDialog(null, "Servico no encontrado");
            
        }
        
    }//GEN-LAST:event_ButtBuscarActionPerformed

    private void TXt_MarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXt_MarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXt_MarcaActionPerformed

    private void TXt_PrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXt_PrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXt_PrecioActionPerformed

    private void TXt_para_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXt_para_buscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXt_para_buscarActionPerformed

    private void TXt_FechaEntreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXt_FechaEntreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXt_FechaEntreActionPerformed
/**
 * Maneja el evento de creación de un nuevo servicio.
 *
 * @param evt El evento de acción asociado a la creación.
 */
    private void bttonCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttonCrearActionPerformed
            // Elimina los componentes del panel de servicios

        panelServicios2.removeAll();

        try {
            // Obtener información de los campos de texto
            int codigoCliente = Integer.parseInt(TXt_cod_cliente.getText());
            String marca = TXt_Marca.getText();
            String descripcion = TXt_Descripcion.getText();
            double precio = Double.parseDouble(TXt_Precio.getText());

            // Formatear fechas
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date fechaRecibido = dateFormat.parse(TXt_FechaRecib.getText());

            Date fechaEntrega = null;
            try {
                String nuevaFechaEntregaString = TXt_FechaEntre.getText();
                if (!nuevaFechaEntregaString.isEmpty()) {
                    fechaEntrega = dateFormat.parse(nuevaFechaEntregaString);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }

            String observaciones = TXt_Observaciones.getText();
            String estado = (String) EStado_box.getSelectedItem();

            // Validar campos obligatorios
            if (codigoCliente <= 0 || marca.isEmpty() || descripcion.isEmpty() ||
                fechaRecibido == null || estado.isEmpty()) {
                throw new IllegalArgumentException("Todos los espacios son necesarios");
            }
            int indexCliente = estaElCliente(TXt_cod_cliente.getText());
            if(indexCliente != -1){
                serviActual.setCodigoCliente(clientes.get(indexCliente).getCodigo());
                serviActual.setCodigoServicio(asignarCodigo());
                serviActual.setMarcaBicicleta(marca);
                serviActual.setDescripcionBicicleta(descripcion);
                serviActual.setPrecio((int) precio);
                serviActual.setFechaRecibido(fechaRecibido);
                serviActual.setFechaEntrega(fechaEntrega);
                serviActual.setObservaciones(observaciones);
                serviActual.setEstado(estado);

                // Agregar el servicio actual a la lista de servicios
                servicios.add(serviActual);
                JOptionPane.showMessageDialog(null, "Servicio creado con éxito");
            }
            else{
                JOptionPane.showMessageDialog(null, "este cliente no existe");
            }
            crearBotonesServicios();

            // Configurar los atributos del servicio actual
            

            
            
            // Guardar la lista de servicios en un archivo JSON
            ServicioGUI2.guardarServicios(servicios);
            // Cargar la lista actualizada de servicios
            cargarServicios();

            // Mostrar mensaje
            
        } catch (HeadlessException | NumberFormatException | ParseException ex) {
            JOptionPane.showMessageDialog(null, "Error inesperado: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }


        // Limpiar los campos de entrada
        limpiarCampos();

    }//GEN-LAST:event_bttonCrearActionPerformed

    private void TXt_FechaRecibActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXt_FechaRecibActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXt_FechaRecibActionPerformed
/**
 * Maneja el evento de eliminación de un servicio.
 *
 * @param evt El evento de acción asociado a la eliminación.
 */
    private void bttonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttonEliminarActionPerformed
        // Obtener el índice del servicio a eliminar
        String txtBuscarServicio = TXt_para_buscar.getText();
        int indexServicio = estaElServicio(txtBuscarServicio);
        panelServicios2.removeAll();

        if (indexServicio != -1) {

            // Verificar si el servicio está cerrado
            Servicio servicio = servicios.get(indexServicio);
            if (servicio.getEstado().equals("Cerrado")) {
                JOptionPane.showMessageDialog(null, "No se puede eliminar un servicio cerrado.");
                return;
            }

            // Eliminar el servicio
            servicios.remove(indexServicio);
            crearBotonesServicios();
            guardarServicios(servicios);
            panelServicios2.revalidate();
            panelServicios2.repaint();
            JOptionPane.showMessageDialog(null, "Servicio eliminado");

        } else {
            JOptionPane.showMessageDialog(null, "Servicio no encontrado");
        }

        limpiarCampos();
    }//GEN-LAST:event_bttonEliminarActionPerformed

    private void TXt_DescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXt_DescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXt_DescripcionActionPerformed
/**
 * Maneja el evento de modificación de un servicio.
 *
 * @param evt El evento de acción asociado a la modificación.
 */
    private void bttonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttonModificarActionPerformed
        // Obtener el índice del servicio a modificar
        String txtBuscarServicio = TXt_para_buscar.getText();
        int indexServicio = estaElServicio(txtBuscarServicio);
        panelServicios2.removeAll();

        // Mostrar confirmación para modificar el servicio
        int respuestaServicio = JOptionPane.showConfirmDialog(null, "¿Estás seguro de modificar el servicio?", "Confirmación", JOptionPane.YES_NO_OPTION);

        // Realizar la modificación si se confirma
        if (indexServicio != -1 && respuestaServicio == JOptionPane.YES_OPTION) {
            // TODO add your handling code here:
            // Mostrar mensaje de advertencia sobre las modificaciones permitidas
            JOptionPane.showMessageDialog(null, "Solo se permite modificar: estado, observaciones, fecha de entrega y precio.", "Advertencia", JOptionPane.WARNING_MESSAGE);

            // Obtener el servicio a partir del índice
            Servicio servicio = servicios.get(indexServicio);

            // Modificar estado
            String nuevoEstadoString = EStado_box.getSelectedItem().toString(); // Reemplaza EstadoComboBox con el nombre real de tu JComboBox
            String nuevoEstado = String.valueOf(nuevoEstadoString);
            servicio.setEstado(nuevoEstado);

            // Modificar observaciones
            String nuevasObservaciones = TXt_Observaciones.getText(); // Reemplaza ObservacionesTextField con el nombre real de tu JTextField
            servicio.setObservaciones(nuevasObservaciones);

            // Modificar fecha de entrega (si tienes un atributo de fecha)
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            try {
                String nuevaFechaEntregaString = TXt_FechaEntre.getText(); // Reemplaza FechaEntregaTextField con el nombre real de tu JTextField
                Date nuevaFechaEntrega = dateFormat.parse(nuevaFechaEntregaString);
                servicio.setFechaEntrega(nuevaFechaEntrega);
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Error al parsear la fecha. Asegúrate de usar el formato correcto (yyyy-MM-dd).", "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Modificar precio
            int nuevoPrecio = Integer.parseInt(TXt_Precio.getText()); // Reemplaza PrecioTextField con el nombre real de tu JTextField
            servicio.setPrecio(nuevoPrecio);

            // Guardar cambios y actualizar la interfaz
            guardarServicios(servicios);
            cargarServicios();
            crearBotonesServicios();
            panelServicios2.revalidate();
            panelServicios2.repaint();

            // Mostrar mensaje de éxito
            JOptionPane.showMessageDialog(null, "Servicio modificado con éxito");
        } else {
            // Mostrar mensaje si el servicio no se encuentra o la modificación es cancelada
            JOptionPane.showMessageDialog(null, "Modificación de servicio cancelada o servicio no encontrado");
        }

        limpiarCampos();

    }//GEN-LAST:event_bttonModificarActionPerformed

    private void TXt_ObservacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXt_ObservacionesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXt_ObservacionesActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Pantalla_Principal p = new Pantalla_Principal();
        p.setVisible(true);
        dispose();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ServicioGUI2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ServicioGUI2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ServicioGUI2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ServicioGUI2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ServicioGUI2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtBuscar;
    private javax.swing.JComboBox<String> EStado_box;
    private javax.swing.JTextField TXt_Descripcion;
    private javax.swing.JTextField TXt_FechaEntre;
    private javax.swing.JTextField TXt_FechaRecib;
    private javax.swing.JTextField TXt_Marca;
    private javax.swing.JTextField TXt_Observaciones;
    private javax.swing.JTextField TXt_Precio;
    private javax.swing.JTextField TXt_cod_cliente;
    private javax.swing.JTextField TXt_para_buscar;
    private javax.swing.JButton bttonCrear;
    private javax.swing.JButton bttonEliminar;
    private javax.swing.JButton bttonModificar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelServicios2;
    // End of variables declaration//GEN-END:variables
/**
 * Formatea la fecha en el formato "yyyy-MM-dd".
 *
 * @param fecha La fecha a formatear.
 * @return Una cadena de texto que representa la fecha formateada.
 */
    private String formatDate(Date fecha) {
  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
  return dateFormat.format(fecha);
}
/**
 * Limpia los campos de entrada en la interfaz de usuario.
 */
private void limpiarCampos() {
  TXt_cod_cliente.setText("");
  TXt_Marca.setText("");
  TXt_Descripcion.setText("");
  TXt_Precio.setText("");
  TXt_FechaRecib.setText("");
  TXt_FechaEntre.setText("");
  TXt_Observaciones.setText("");
  EStado_box.setSelectedItem("Abierto");  
}
}