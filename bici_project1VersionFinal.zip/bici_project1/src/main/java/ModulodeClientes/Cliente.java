package ModulodeClientes;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.Date;

/**
 * Clase que representa a un cliente.
 */
public class Cliente {

    private static int codigoActual = 1;

    private int codigo;
    private String nombre;
    private String apellidos;
    private String telefono;
    private String correo;
    private String provincia;
    private String canton;
    private String distrito;
    private Date fechaNacimiento;

    /**
     * Constructor de la clase Cliente.
     */
    public Cliente() {
        codigo = 1;
        nombre = "";
        apellidos = "";
        telefono = "";
        correo = "";
        provincia = "";
        canton = "";
        distrito = "";
        fechaNacimiento = new Date();  // Puedes establecer una fecha predeterminada o inicializarla según tus necesidades.
    }

    // Getters and Setters

    /**
     * Obtiene el código del cliente.
     * @return El código del cliente.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Establece el código del cliente.
     * @param codigo El nuevo código del cliente.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Obtiene el nombre del cliente.
     * @return El nombre del cliente.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del cliente.
     * @param nombre El nuevo nombre del cliente.
     */
    public void setNombre(String nombre) {
        this.nombre = sinEspacios(nombre);
    }

    /**
     * Obtiene los apellidos del cliente.
     * @return Los apellidos del cliente.
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * Establece los apellidos del cliente.
     * @param apellidos Los nuevos apellidos del cliente.
     */
    public void setApellidos(String apellidos) {
        this.apellidos = sinEspacios(apellidos);
    }

    /**
     * Obtiene el teléfono del cliente.
     * @return El teléfono del cliente.
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Establece el teléfono del cliente.
     * @param telefono El nuevo teléfono del cliente.
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Obtiene el correo del cliente.
     * @return El correo del cliente.
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Establece el correo del cliente.
     * @param correo El nuevo correo del cliente.
     */
    public void setCorreo(String correo) {
        this.correo = sinEspacios(correo);
    }

    /**
     * Obtiene la provincia del cliente.
     * @return La provincia del cliente.
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * Establece la provincia del cliente.
     * @param provincia La nueva provincia del cliente.
     */
    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    /**
     * Obtiene el cantón del cliente.
     * @return El cantón del cliente.
     */
    public String getCanton() {
        return canton;
    }

    /**
     * Establece el cantón del cliente.
     * @param canton El nuevo cantón del cliente.
     */
    public void setCanton(String canton) {
        this.canton = sinEspacios(canton);
    }

    /**
     * Obtiene el distrito del cliente.
     * @return El distrito del cliente.
     */
    public String getDistrito() {
        return distrito;
    }

    /**
     * Establece el distrito del cliente.
     * @param distrito El nuevo distrito del cliente.
     */
    public void setDistrito(String distrito) {
        this.distrito = sinEspacios(distrito);
    }

    /**
     * Obtiene la fecha de nacimiento del cliente.
     * @return La fecha de nacimiento del cliente.
     */
    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    /**
     * Establece la fecha de nacimiento del cliente.
     * @param fechaNacimiento La nueva fecha de nacimiento del cliente.
     */
    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    // Métodos adicionales

    /**
     * Elimina los espacios en blanco al principio y al final de un texto.
     * @param texto El texto a procesar.
     * @return El texto sin espacios en blanco al principio y al final.
     */
    private String sinEspacios(String texto) {
        return texto.trim();
    }

    /**
     * Realiza una búsqueda de clientes.
     */
    public void buscar() {
        // Código de búsqueda
    }

    /**
     * Agrega un nuevo cliente.
     */
    public void agregar() {
        // Código para agregar
    }

    /**
     * Modifica un cliente existente.
     */
    public void modificar() {
        // Código para modificar
    }

    /**
     * Elimina un cliente existente.
     */
    public void eliminar() {
        // Código para eliminar
    }
}
