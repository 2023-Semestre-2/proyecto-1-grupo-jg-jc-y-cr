package ModulodeClientes;

import ControldeAcceso.Pantalla_Principal;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;
import ModulodeClientes.Cliente;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.awt.HeadlessException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase que representa la interfaz gráfica de usuario para la gestión de clientes.
 */
public class ClienteGUI extends JFrame {
    private ArrayList<Cliente> Clientes;
    private Cliente clienteActual;
    private ArrayList<JButton> botonesClientes;
    private String[] Apellidos;

    /**
     * Constructor de la clase ClienteGUI.
     */
    public ClienteGUI() {
        initComponents();
        Clientes = new ArrayList<>();
        clienteActual = new Cliente();
        botonesClientes = new ArrayList<>();
        Clientes = cargarClientes();
        crearBotonesClientes();
    }

    // Getters and Setters

    /**
     * Obtiene la lista de clientes.
     * @return La lista de clientes.
     */
    public ArrayList<Cliente> getClientes() {
        return Clientes;
    }

    /**
     * Establece la lista de clientes.
     * @param clientes La nueva lista de clientes.
     */
    public void setClientes(ArrayList<Cliente> clientes) {
        this.Clientes = clientes;
    }

    /**
     * Obtiene el cliente actual.
     * @return El cliente actual.
     */
    public Cliente getClienteActual() {
        return clienteActual;
    }

    /**
     * Establece el cliente actual.
     * @param clienteActual El nuevo cliente actual.
     */
    public void setClienteActual(Cliente clienteActual) {
        this.clienteActual = clienteActual;
    }

    /**
     * Carga los clientes desde un archivo JSON.
     * @return La lista de clientes cargada desde el archivo.
     */
    public static ArrayList<Cliente> cargarClientes() {
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        try (Reader reader = new FileReader("clientes.json")) {
            Gson gson = new Gson();
            Cliente[] clientesArray = gson.fromJson(reader, Cliente[].class);
            if (clientesArray != null) {
                listaClientes.addAll(Arrays.asList(clientesArray));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listaClientes;
    }

    /**
     * Guarda la lista de clientes en un archivo JSON.
     * @param Clientes La lista de clientes a guardar.
     */
    public void guardarClientes(ArrayList<Cliente> Clientes) {
        try (Writer writer = new FileWriter("Clientes.json")) {
            Gson gson = new GsonBuilder().create();
            gson.toJson(Clientes, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Crea botones para cada cliente y los agrega al panel visual.
     */
    private void crearBotonesClientes() {
        for (Cliente clie : Clientes) {
            JButton boton = new JButton(clie.getCodigo()+"  "+clie.getNombre()+" "+clie.getApellidos()+clie.getProvincia());
            boton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String txtBuscar = clie.getNombre();
                    int indexCliente = estaElCliente(txtBuscar);
                    NombreTxt.setText(Clientes.get(indexCliente).getNombre());
                    TelefonoTxt.setText(Clientes.get(indexCliente).getTelefono());
                    ApellidoTxt.setText(""+Clientes.get(indexCliente).getApellidos());
                    CantonTxt.setText(""+Clientes.get(indexCliente).getCanton());
                    DistritoTxt.setText(Clientes.get(indexCliente).getDistrito());
                    CorreoElectroTxt.setText(Clientes.get(indexCliente).getCorreo());
                    Provincia.setSelectedItem(Clientes.get(indexCliente).getProvincia());
                    Buscar.setText(Clientes.get(indexCliente).getNombre());
                    FechaTxt.setText(formatDate(Clientes.get(indexCliente).getFechaNacimiento()));
                }
            });
            botonesClientes.add(boton);
        }
        for (JButton boton : botonesClientes) {
            ClientesVisual.add(boton);
        }
        botonesClientes.clear();
    }

    /**
     * Busca un cliente por nombre y apellidos en la lista de clientes.
     * @param nombre El nombre del cliente a buscar.
     * @param apellidos Los apellidos del cliente a buscar.
     * @param clientes La lista de clientes en la que buscar.
     * @return El índice del cliente si se encuentra, -1 si no se encuentra.
     */
    public int estaElCliente(String nombre, String apellidos, ArrayList<Cliente> clientes) {
        String nombreFix = nombre.trim();
        String apellidosFix = apellidos.trim();
        for (Cliente cliente : clientes) {
            if (cliente.getNombre().equals(nombreFix) && 
                cliente.getApellidos().equals(apellidosFix)) {
                return clientes.indexOf(cliente);
            }
        }
        return -1;
    }

    /**
     * Asigna un nuevo código para un cliente.
     * @return El nuevo código asignado.
     */
    private int asignarCodigo() {
        int codigoAsignado = 1;
        for (Cliente cliente : Clientes) {
            int code = cliente.getCodigo();
            if (code > codigoAsignado) {
                codigoAsignado = code;
            }
        }
        return codigoAsignado + 1;
    }

    /**
     * Busca un cliente por nombre en la lista de clientes.
     * @param nombre El nombre del cliente a buscar.
     * @return El índice del cliente si se encuentra, -1 si no se encuentra.
     */
    public int estaElCliente(String nombre) {
        String nombreFix = nombre.trim();
        int value = -1;
        for(Cliente clie : Clientes) {
            String posCode =""+clie.getCodigo();
            if(clie.getNombre().equals(nombreFix) || posCode.equals(nombreFix)) {
                return Clientes.indexOf(clie);
            }
        }
        return value;
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Buscar = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        NombreTxt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        TelefonoTxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        CorreoElectroTxt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        CantonTxt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        DistritoTxt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        Provincia = new javax.swing.JComboBox<>();
        BotCrear = new javax.swing.JButton();
        BoutModificar = new javax.swing.JButton();
        bottEliminar = new javax.swing.JButton();
        BtonBuscar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        FechaTxt = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        ApellidoTxt = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        ClientesVisual = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nombre");

        jLabel2.setText("Telefono");

        TelefonoTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelefonoTxtActionPerformed(evt);
            }
        });

        jLabel3.setText("Correo Electronico");

        CorreoElectroTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CorreoElectroTxtActionPerformed(evt);
            }
        });

        jLabel4.setText("Provincia");

        jLabel5.setText("Canton");

        CantonTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CantonTxtActionPerformed(evt);
            }
        });

        jLabel6.setText("Distrito");

        jLabel7.setText("Fecha de nacimiento");

        Provincia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "San Jose", "Alajuela", "Heredia", "Cartago", "Guanacaste", "Puntarenas", "Limon" }));
        Provincia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProvinciaActionPerformed(evt);
            }
        });

        BotCrear.setText("Crear");
        BotCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotCrearActionPerformed(evt);
            }
        });

        BoutModificar.setText("Modificar");
        BoutModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BoutModificarActionPerformed(evt);
            }
        });

        bottEliminar.setText("Eliminar");
        bottEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bottEliminarActionPerformed(evt);
            }
        });

        BtonBuscar.setText("Buscar");
        BtonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtonBuscarActionPerformed(evt);
            }
        });

        jLabel8.setText("Buscar cliente");

        FechaTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FechaTxtActionPerformed(evt);
            }
        });

        jLabel9.setText("Apellido");

        ApellidoTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ApellidoTxtActionPerformed(evt);
            }
        });

        ClientesVisual.setLayout(new java.awt.GridLayout(0, 1));
        jScrollPane1.setViewportView(ClientesVisual);

        jButton5.setText("Atras");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(BotCrear)
                                .addGap(18, 18, 18)
                                .addComponent(BoutModificar)
                                .addGap(33, 33, 33)
                                .addComponent(bottEliminar))
                            .addComponent(jLabel9)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(CorreoElectroTxt, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(TelefonoTxt, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(NombreTxt, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(ApellidoTxt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE))
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(Provincia, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(FechaTxt, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(DistritoTxt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
                                .addComponent(CantonTxt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE))
                            .addComponent(jLabel7))
                        .addGap(68, 68, 68))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton5)
                        .addGap(288, 288, 288)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BtonBuscar))
                    .addComponent(jScrollPane1))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jButton5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotCrear)
                    .addComponent(BoutModificar)
                    .addComponent(bottEliminar)
                    .addComponent(BtonBuscar))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(NombreTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ApellidoTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TelefonoTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CorreoElectroTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addGap(5, 5, 5)
                        .addComponent(Provincia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(CantonTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(DistritoTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jScrollPane1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(FechaTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CorreoElectroTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CorreoElectroTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CorreoElectroTxtActionPerformed

    private void TelefonoTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelefonoTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TelefonoTxtActionPerformed

    private void ProvinciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProvinciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProvinciaActionPerformed
/**
 * Método que se ejecuta cuando se hace clic en el botón "Crear" para agregar un nuevo cliente.
 * @param evt El evento de acción que desencadena la ejecución del método.
 */
    private void BotCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotCrearActionPerformed
        try {
            ClientesVisual.removeAll();
            String textoNombre = NombreTxt.getText();
            String textoApellidos = ApellidoTxt.getText();
            String textoTelefono = TelefonoTxt.getText() ;
            String textoCorreo = CorreoElectroTxt.getText();
            String textoProvincia = Provincia.getSelectedItem().toString();
            String textoCanton = CantonTxt.getText();
            String textoDistrito = DistritoTxt.getText();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date fechaNacimiento = dateFormat.parse(FechaTxt.getText());
            String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                      "[a-zA-Z0-9_+&*-]+)*@" +
                      "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                      "A-Z]{2,7}$";
            String[] apellidos = textoApellidos.split(" ");

// Guardar en la base de datos
            String guardarApellidos = apellidos[0] + " " + apellidos[1];
            
            
            
            
           if(textoTelefono.length() != 8) {
  JOptionPane.showMessageDialog(null, "El teléfono debe tener 8 dígitos");
  return; 
}
           
   try {
  Long.parseLong(textoTelefono); 
} catch (NumberFormatException e) {
  JOptionPane.showMessageDialog(null, "El teléfono solo puede contener números");
  return;
}
   
   if (!textoCorreo.matches(emailRegex)) {
  JOptionPane.showMessageDialog(null, "Formato de correo inválido");
  return;  
}
           
           
            
            
            
            //Agrega ProduActual a la lista de producto y resetea produActual
            if(estaElCliente(textoNombre.trim()) == -1){
                clienteActual.setCodigo(asignarCodigo());
                clienteActual.setNombre(textoNombre.trim());
                clienteActual.setApellidos(textoApellidos);
                clienteActual.setCanton(textoCanton);
                clienteActual.setCorreo(textoCorreo);
                clienteActual.setProvincia(textoProvincia);
                clienteActual.setDistrito(textoDistrito);
                clienteActual.setTelefono(textoTelefono);
                clienteActual.setFechaNacimiento(fechaNacimiento);
                Clientes.add(clienteActual);
                clienteActual = new Cliente();
                
                //manda el producto nuevo al Json
                guardarClientes(Clientes);
                cargarClientes();
                JOptionPane.showMessageDialog(null, "Cliente registrado con exito");
            }
            else{
                JOptionPane.showMessageDialog(null, "este Cliente ya existe");
            }
            
            //Vacia los campos de texto
            NombreTxt.setText("");
            ApellidoTxt.setText("");
            TelefonoTxt.setText("");
            CorreoElectroTxt.setText("");
            CantonTxt.setText("");
            DistritoTxt.setText("");
            FechaTxt.setText(""); 
            guardarClientes(Clientes);
            cargarClientes();
            crearBotonesClientes();
            ClientesVisual.revalidate();
            ClientesVisual.repaint();
        } catch (ParseException ex) {
            Logger.getLogger(ClienteGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_BotCrearActionPerformed

    private void ApellidoTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ApellidoTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ApellidoTxtActionPerformed
/**
 * Método que se ejecuta cuando se hace clic en el botón "Modificar" para realizar cambios en un cliente existente.
 * Realiza una confirmación mediante un cuadro de diálogo antes de realizar la modificación.
 * Actualiza la información del cliente con los datos proporcionados en la interfaz gráfica.
 * Muestra un mensaje de éxito después de realizar la modificación.
 * Limpia los campos de texto y actualiza la interfaz.
 * @param evt El evento de acción que desencadena la ejecución del método.
 */
    private void BoutModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BoutModificarActionPerformed
        // TODO add your handling code here:
        ClientesVisual.removeAll();
        int respuesta = JOptionPane.showConfirmDialog(null, "estas seguro de modificar el Cliente?", "Confirmación", JOptionPane.YES_NO_OPTION);
        String txtBuscar = Buscar.getText();
        int indexProducto = estaElCliente(txtBuscar);
        clienteActual = Clientes.get(indexProducto);
        
        //saca la informacion de la GUI
        String textoNombre = NombreTxt.getText();
        String textoApellidos = ApellidoTxt.getText();
        String textoTelefono = TelefonoTxt.getText() ;
        String textoCorreo = CorreoElectroTxt.getText();
        String textoProvincia = Provincia.getSelectedItem().toString();
        String textoCanton = CantonTxt.getText();
        String textoDistrito = DistritoTxt.getText();
       SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
       String textoFecha = FechaTxt.getText();
       Date FechaNas = null;
       String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                      "[a-zA-Z0-9_+&*-]+)*@" +
                      "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                      "A-Z]{2,7}$";
           
       
            
           if(textoTelefono.length() != 8) {
  JOptionPane.showMessageDialog(null, "El teléfono debe tener 8 dígitos");
  return; 
}
           
   try {
  Long.parseLong(textoTelefono); 
} catch (NumberFormatException e) {
  JOptionPane.showMessageDialog(null, "El teléfono solo puede contener números");
  return;
}
   
   if (!textoCorreo.matches(emailRegex)) {
  JOptionPane.showMessageDialog(null, "Formato de correo inválido");
  return;  
}
   
        try {
            FechaNas = dateFormat.parse(textoFecha);
        } catch (ParseException ex) {
            Logger.getLogger(ClienteGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        if (respuesta == JOptionPane.YES_OPTION){
            clienteActual.setNombre(textoNombre.trim());
            clienteActual.setApellidos(textoApellidos);
            clienteActual.setCanton(textoCanton);
            clienteActual.setCorreo(textoCorreo);
            clienteActual.setProvincia(textoProvincia);
            clienteActual.setDistrito(textoDistrito);
            clienteActual.setTelefono(textoTelefono);
            clienteActual.setFechaNacimiento(FechaNas);
            JOptionPane.showMessageDialog(null, "Cliente Modificado con exito");
        }
        //Vacia los campos de texto 
        NombreTxt.setText("");
        ApellidoTxt.setText("");
        TelefonoTxt.setText("");
        CorreoElectroTxt.setText("");
        CantonTxt.setText("");
        DistritoTxt.setText("");
        FechaTxt.setText(""); 
        guardarClientes(Clientes);
        cargarClientes();
        crearBotonesClientes();
        ClientesVisual.revalidate();
        ClientesVisual.repaint();
        
    }//GEN-LAST:event_BoutModificarActionPerformed
/**
 * Método que se ejecuta cuando se hace clic en el botón "Eliminar" para eliminar un cliente existente.
 * Realiza una confirmación mediante un cuadro de diálogo antes de realizar la eliminación.
 * Elimina el cliente de la lista si la confirmación es afirmativa.
 * Limpia los campos de texto, actualiza la interfaz y guarda los cambios en la base de datos.
 * @param evt El evento de acción que desencadena la ejecución del método.
 */
    private void bottEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bottEliminarActionPerformed
        // TODO add your handling code here:
        int respuesta = JOptionPane.showConfirmDialog(null, "estas seguro de eliminar el cliente?", "Confirmación", JOptionPane.YES_NO_OPTION);
        String txtBuscar = Buscar.getText();
        int indexProducto = estaElCliente(txtBuscar);
        if (respuesta == JOptionPane.YES_OPTION){
            Clientes.remove(indexProducto);
        }
        NombreTxt.setText("");
        ApellidoTxt.setText("");
        TelefonoTxt.setText("");
        CorreoElectroTxt.setText("");
        CantonTxt.setText("");
        DistritoTxt.setText("");
        FechaTxt.setText("");
        ClientesVisual.removeAll();
        guardarClientes(Clientes);
        cargarClientes();
        crearBotonesClientes();
        ClientesVisual.revalidate();
        ClientesVisual.repaint();
        
        
    }//GEN-LAST:event_bottEliminarActionPerformed
/**
 * Método que se ejecuta cuando se hace clic en el botón "Buscar" para buscar un cliente en la lista.
 * Obtiene el nombre y apellidos ingresados en el campo de búsqueda y realiza la búsqueda en la lista de clientes.
 * Si encuentra el cliente, actualiza los campos de texto con la información del cliente encontrado.
 * Si el cliente no existe, muestra un mensaje de advertencia.
 * @param evt El evento de acción que desencadena la ejecución del método.
 */
    private void BtonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtonBuscarActionPerformed
        // TODO add your handling code here:
        String txtBuscar = Buscar.getText();
        String mostrarApellidos = Apellidos[0] + " " + Apellidos[1];
        String txtNombre = Buscar.getText(); 
        String txtApellidos = ""; // Dejar vacío si no se busca por apellidos
        int indexCliente = estaElCliente(txtNombre, txtApellidos, Clientes);
  
  if(indexCliente >= 0){
            if(indexCliente >= 0){
                NombreTxt.setText(Clientes.get(indexCliente).getNombre());
                TelefonoTxt.setText(Clientes.get(indexCliente).getTelefono());
                ApellidoTxt.setText(""+Clientes.get(indexCliente).getApellidos());
                CantonTxt.setText(""+Clientes.get(indexCliente).getCanton());
                DistritoTxt.setText(Clientes.get(indexCliente).getDistrito());
                CorreoElectroTxt.setText(Clientes.get(indexCliente).getCorreo());
                Provincia.setSelectedItem(Clientes.get(indexCliente).getProvincia());
                Buscar.setText(Clientes.get(indexCliente).getNombre());
                FechaTxt.setText(formatDate(Clientes.get(indexCliente).getFechaNacimiento()));
                ApellidoTxt.setText(mostrarApellidos);
                
                
                
                
            }
            else{
                JOptionPane.showMessageDialog(null, "el cliente no existe");
            }
  }
    }//GEN-LAST:event_BtonBuscarActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        Pantalla_Principal p = new Pantalla_Principal();
        p.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void FechaTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FechaTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FechaTxtActionPerformed

    private void CantonTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CantonTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CantonTxtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClienteGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClienteGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClienteGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClienteGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClienteGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ApellidoTxt;
    private javax.swing.JButton BotCrear;
    private javax.swing.JButton BoutModificar;
    private javax.swing.JButton BtonBuscar;
    private javax.swing.JTextField Buscar;
    private javax.swing.JTextField CantonTxt;
    private javax.swing.JPanel ClientesVisual;
    private javax.swing.JTextField CorreoElectroTxt;
    private javax.swing.JTextField DistritoTxt;
    private javax.swing.JTextField FechaTxt;
    private javax.swing.JTextField NombreTxt;
    private javax.swing.JComboBox<String> Provincia;
    private javax.swing.JTextField TelefonoTxt;
    private javax.swing.JButton bottEliminar;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
/**
 * Convierte una fecha dada al formato de cadena "dd/MM/yyyy".
 * 
 * @param fecha La fecha a formatear.
 * @return Una cadena que representa la fecha en el formato "dd/MM/yyyy".
 */
    private String formatDate(Date fecha) {
  SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy"); 
  return dateFormat.format(fecha);
}
}  
