package com.mycompany.bici_project1;



public class Bici_project1 {

    public static void main(String[] args) {
        
    }


    
}
