package Modulo_de_Producto;

/**
 * Clase que representa un tipo de producto en el sistema.
 * Contiene información como código y nombre del tipo de producto.
 */
public class TipoDeProducto {
    private int codigo; // Código único del tipo de producto.
    private String nombre; // Nombre del tipo de producto.

    /**
     * Constructor de la clase TipoDeProducto.
     * Inicializa el código con 1 y establece el nombre del tipo de producto.
     * @param nombre El nombre del tipo de producto.
     */
    public TipoDeProducto(String nombre) {
        codigo = 1;
        setNombre(nombre);
    }

    // Getters and Setters

    /**
     * Método para obtener el código del tipo de producto.
     * @return El código único del tipo de producto.
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Método para establecer el código del tipo de producto.
     * @param codigo El nuevo código a asignar al tipo de producto.
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * Método para obtener el nombre del tipo de producto.
     * @return El nombre del tipo de producto.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Método para establecer el nombre del tipo de producto.
     * @param nombre El nuevo nombre a asignar al tipo de producto.
     */
    public void setNombre(String nombre) {
        this.nombre = sinEspacios(nombre);
    }
    // Final de Getters and Setters 

    /**
     * Método para generar un nuevo código para el tipo de producto.
     */
    private void generarCodigo() {
        setCodigo(codigo + 1);
    }

    /**
     * Método para eliminar espacios en blanco al principio y al final de un nombre.
     * @param nombre El nombre a ser formateado.
     * @return El nombre sin espacios en blanco al principio y al final.
     */
    private String sinEspacios(String nombre) {
        return nombre.trim();
    }
}
