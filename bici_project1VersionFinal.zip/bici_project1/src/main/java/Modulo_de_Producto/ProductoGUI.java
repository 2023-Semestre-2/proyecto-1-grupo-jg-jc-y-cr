
package Modulo_de_Producto;

import ControldeAcceso.Pantalla_Principal;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 * Clase que representa la interfaz gráfica de usuario para la gestión de productos.
 * Permite la creación, modificación, eliminación y búsqueda de productos.
 * Además, interactúa con archivos JSON para almacenar y cargar datos de productos.
 * Extiende javax.swing.JFrame.
 */
public class ProductoGUI extends javax.swing.JFrame {
    
    private ArrayList<Producto> productos; // Lista de productos en el sistema.
    private Producto produActual; // Producto actual en edición o visualización.
    private ArrayList<JButton> botonesProductos; // Lista de botones asociados a productos en la interfaz.

    /**
     * Crea una nueva instancia de ProductoGUI.
     * Inicializa componentes, carga productos desde el archivo JSON y configura la interfaz.
     */
    public ProductoGUI() {
        initComponents();
        produActual = new Producto();
        productos = cargarProductos();
        this.botonesProductos = new ArrayList<>();
        crearBotonesProductos();
        Tamaño.setEnabled(false);
    }
    
    //Getters and Setters
    /**
     * Obtiene la lista de productos almacenada en la instancia de ProductoGUI.
     * @return Lista de productos.
     */
    public ArrayList<Producto> getProductos() {
        return productos;
    }

    /**
     * Establece la lista de productos en la instancia de ProductoGUI.
     * @param productos Nueva lista de productos a asignar.
     */
    public void setProductos(ArrayList<Producto> productos) {
        this.productos = productos;
    }

    /**
     * Obtiene el producto actualmente en edición o visualización en la instancia de ProductoGUI.
     * @return Producto actual.
     */
    public Producto getProduActual() {
        return produActual;
    }

    /**
     * Establece el producto actual en la instancia de ProductoGUI.
     * @param produActual Nuevo producto actual a asignar.
     */
    public void setProduActual(Producto produActual) {
        this.produActual = produActual;
    }

    
    /**
     * Guarda la lista de productos en un archivo JSON.
     * @param productos Lista de productos a ser guardada.
     */
    public void guardarServicios(ArrayList<Producto> productos) {
        try (Writer writer = new FileWriter("Productos.json")) {
            Gson gson = new GsonBuilder().create();
            gson.toJson(productos, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Carga la lista de productos desde un archivo JSON.
     * @return Lista de productos cargada desde el archivo.
     */
    public static ArrayList<Producto> cargarProductos() {
        ArrayList<Producto> listaProductos = new ArrayList<>();
        try (Reader reader = new FileReader("Productos.json")) {
            Gson gson = new Gson();
            Producto[] productosArray = gson.fromJson(reader, Producto[].class);
            if (productosArray != null) {
                listaProductos.addAll(Arrays.asList(productosArray));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listaProductos;
    }

    /**
     * Verifica si un producto con el nombre proporcionado ya existe en la lista de productos.
     * @param nombre Nombre del producto a buscar.
     * @return Índice del producto si existe, -1 si no se encuentra.
     */
    public int estaElProducto(String nombre) {
        String nombreFix = nombre.trim();
        int value = -1;
        for (Producto pro : productos) {
            String posCode = "" + pro.getCodigo();
            if (pro.getNombre().equals(nombreFix) || posCode.equals(nombreFix)) {
                return productos.indexOf(pro);
            }
        }
        return value;
    }
    
    
    /**
     * Crea botones dinámicamente para cada producto y los agrega al panelProductos.
     * Cada botón muestra información del producto y permite su selección.
     * Al seleccionar un botón, se actualizan los campos de texto con la información del producto correspondiente.
     */
    private void crearBotonesProductos() {
        for (Producto produ : productos) {
            JButton boton = new JButton(produ.getCodigo() + "  " + produ.getNombre() + "  " +
                    produ.getMarca() + "  " + produ.getTipo() + "  $" + produ.getPrecio());
            boton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String txtBuscar = produ.getNombre();
                    int indexProducto = estaElProducto(txtBuscar);
                    Nombre.setText(productos.get(indexProducto).getNombre());
                    Marca.setText(productos.get(indexProducto).getMarca());
                    Precio.setText("" + productos.get(indexProducto).getPrecio());
                    Cantidad.setText("" + productos.get(indexProducto).getCantidad());
                    TipoProducto.setSelectedItem(productos.get(indexProducto).getTipo());
                    Tamaño.setSelectedItem(productos.get(indexProducto).getTamaño());
                    Buscar.setText(productos.get(indexProducto).getNombre());
                }
            });

            botonesProductos.add(boton);
        }

        for (JButton boton : botonesProductos) {
            panelProductos.add(boton);
        }
        botonesProductos.clear();
    }

    /**
     * Asigna un nuevo código para un producto basándose en el código del último producto en la lista.
     * @return Nuevo código asignado.
     */
    private int asignarCodigo() {
        int codigoAsignado = 1;
        for (Producto producto : productos) {
            int code = producto.getCodigo();
            codigoAsignado = code;
        }
        return codigoAsignado + 1;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Nombre = new javax.swing.JTextField();
        BtnCrear = new javax.swing.JButton();
        BtnModificar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        Buscar = new javax.swing.JTextField();
        Precio = new javax.swing.JTextField();
        Marca = new javax.swing.JTextField();
        Cantidad = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        TipoProducto = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        Tamaño = new javax.swing.JComboBox<>();
        BtnEliminar = new javax.swing.JButton();
        BtnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelProductos = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NombreActionPerformed(evt);
            }
        });

        BtnCrear.setText("Crear");
        BtnCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCrearActionPerformed(evt);
            }
        });

        BtnModificar.setText("Modificar");
        BtnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnModificarActionPerformed(evt);
            }
        });

        jLabel3.setText("Buscar Producto");

        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });

        Precio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrecioActionPerformed(evt);
            }
        });

        Marca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MarcaActionPerformed(evt);
            }
        });

        Cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CantidadActionPerformed(evt);
            }
        });

        jLabel4.setText("Nombre del Articulo");

        jLabel5.setText("Marca");

        jLabel6.setText("Precio");

        jLabel7.setText("Cantidad");

        jLabel8.setText("Tipo del producto");

        TipoProducto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Accesorios", "Suplemetos Alimenticios", "Bicicleta" }));
        TipoProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoProductoActionPerformed(evt);
            }
        });

        jLabel9.setText("Tamaño");

        Tamaño.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "12", "16", "22", "26", "27", "27.5 ", "29" }));
        Tamaño.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TamañoActionPerformed(evt);
            }
        });

        BtnEliminar.setText("Eliminar");
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });

        BtnBuscar.setText("Buscar");
        BtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarActionPerformed(evt);
            }
        });

        panelProductos.setToolTipText("");
        panelProductos.setLayout(new java.awt.GridLayout(0, 1));
        jScrollPane1.setViewportView(panelProductos);

        jLabel1.setText("Productos");

        jButton1.setText("Atras");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(BtnCrear)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(BtnModificar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(BtnEliminar))
                            .addComponent(jLabel4)
                            .addComponent(jLabel8)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(TipoProducto, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Nombre, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(Tamaño, javax.swing.GroupLayout.Alignment.LEADING, 0, 171, Short.MAX_VALUE))
                            .addComponent(jLabel7)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Marca, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Precio, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(109, 109, 109)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(84, 84, 84))
                                    .addComponent(Buscar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(BtnBuscar))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(jButton1))
                .addGap(32, 32, 32))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jButton1)
                .addGap(3, 3, 3)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnCrear)
                    .addComponent(BtnModificar)
                    .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnEliminar)
                    .addComponent(BtnBuscar))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 355, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Tamaño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(5, 5, 5)
                        .addComponent(Marca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    /**
     * Maneja la acción del botón "Crear". Obtiene la información ingresada en la GUI,
     * crea un nuevo producto, lo agrega a la lista de productos y guarda la información en un archivo JSON.
     * Si el producto ya existe, muestra un mensaje de advertencia.
     * Limpia los campos de texto después de realizar la operación.
     * Actualiza la interfaz de usuario para reflejar los cambios.
     *
     * @param evt Evento de acción del botón.
     */
    private void BtnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCrearActionPerformed
        
        //saca la informacion de la GUI
        panelProductos.removeAll();
        String textoNombre = Nombre.getText();
        String textoTipo = TipoProducto.getSelectedItem().toString();
        String textoTamaño = Tamaño.getSelectedItem().toString();
        String textoMarca = Marca.getText();
        String textoPrecio = Precio.getText();
        String textoCantidad = Cantidad.getText();
        
        int intPrecio = Integer.parseInt(textoPrecio);
        int intCantidad = Integer.parseInt(textoCantidad);

        // Guarda los datos como atributos de produActual para guardarlos despues en el json
        
        
        //Agrega ProduActual a la lista de producto y resetea produActual
        if(estaElProducto(textoNombre.trim()) == -1){
            produActual.setCodigo(asignarCodigo());
            produActual.setNombre(textoNombre.trim());
            produActual.setTipo(textoTipo);
            produActual.setTamaño(textoTamaño);
            produActual.setMarca(textoMarca.trim());
            produActual.setPrecio(intPrecio);
            produActual.setCantidad(intCantidad);
            productos.add(produActual);
            produActual = new Producto();
 
            //manda el producto nuevo al Json
            guardarServicios(productos);
            cargarProductos();
            JOptionPane.showMessageDialog(null, "Producto creado con exito");
        }
        else{
            JOptionPane.showMessageDialog(null, "este producto ya existe");
        }
        
        //Vacia los campos de texto 
        Nombre.setText("");
        Marca.setText("");
        Precio.setText("");
        Cantidad.setText("");
        guardarServicios(productos);
        cargarProductos();
        crearBotonesProductos();
        panelProductos.revalidate();
        panelProductos.repaint();
    }//GEN-LAST:event_BtnCrearActionPerformed

    private void NombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NombreActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BuscarActionPerformed

    private void PrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PrecioActionPerformed

    private void MarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MarcaActionPerformed

    private void CantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CantidadActionPerformed
    /**
     * Maneja la acción de selección de tipo de producto en el JComboBox "TipoProducto".
     * Habilita o deshabilita el JComboBox "Tamaño" según el tipo de producto seleccionado.
     *
     * @param evt Evento de acción del JComboBox "TipoProducto".
     */
    private void TipoProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoProductoActionPerformed
        // TODO add your handling code here:
        String selectedOption = (String) TipoProducto.getSelectedItem();

        if ("Bicicleta".equals(selectedOption)) {
            Tamaño.setEnabled(true);
        } else {
            Tamaño.setEnabled(false);
        }
    }//GEN-LAST:event_TipoProductoActionPerformed

    private void TamañoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TamañoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TamañoActionPerformed
    /**
     * Maneja la acción del botón de búsqueda.
     * Busca un producto en la lista según el texto ingresado y actualiza los campos de la GUI con la información del producto encontrado.
     * Muestra un mensaje si el producto no existe.
     *
     * @param evt Evento de acción del botón de búsqueda.
     */
    private void BtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarActionPerformed
        // TODO add your handling code here:
        String txtBuscar = Buscar.getText();
        int indexProducto = estaElProducto(txtBuscar);
        System.out.println(""+indexProducto);
            if(indexProducto >= 0){
                Nombre.setText(productos.get(indexProducto).getNombre());
                Marca.setText(productos.get(indexProducto).getMarca());
                Precio.setText(""+productos.get(indexProducto).getPrecio());
                Cantidad.setText(""+productos.get(indexProducto).getCantidad());
                TipoProducto.setSelectedItem(productos.get(indexProducto).getTipo());
                Tamaño.setSelectedItem(productos.get(indexProducto).getTamaño());
                
            }
            else{
                JOptionPane.showMessageDialog(null, "el producto no existe");
            }
        
        
    }//GEN-LAST:event_BtnBuscarActionPerformed
    /**
     * Maneja la acción del botón de modificación de producto.
     * Muestra una confirmación y, si se confirma, actualiza la información del producto seleccionado con los datos ingresados en la GUI.
     * Vacia los campos de texto después de la modificación.
     *
     * @param evt Evento de acción del botón de modificación.
     */
    private void BtnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnModificarActionPerformed
        // TODO add your handling code here:
        panelProductos.removeAll();
        int respuesta = JOptionPane.showConfirmDialog(null, "estas seguro de modificar el producto?", "Confirmación", JOptionPane.YES_NO_OPTION);
        String txtBuscar = Buscar.getText();
        int indexProducto = estaElProducto(txtBuscar);
        produActual = productos.get(indexProducto);
        
        //saca la informacion de la GUI
        String textoNombre = Nombre.getText();
        String textoTipo = TipoProducto.getSelectedItem().toString();
        String textoTamaño = Tamaño.getSelectedItem().toString();
        String textoMarca = Marca.getText();
        String textoPrecio = Precio.getText();
        String textoCantidad = Cantidad.getText();
        
        int intPrecio = Integer.parseInt(textoPrecio);
        int intCantidad = Integer.parseInt(textoCantidad);
        
        if (respuesta == JOptionPane.YES_OPTION){
            produActual.setNombre(textoNombre.trim());
            produActual.setTipo(textoTipo);
            produActual.setTamaño(textoTamaño);
            produActual.setMarca(textoMarca.trim());
            produActual.setPrecio(intPrecio);
            produActual.setCantidad(intCantidad);
            JOptionPane.showMessageDialog(null, "Producto Modificado con exito");
        }
        //Vacia los campos de texto 
        Nombre.setText("");
        Marca.setText("");
        Precio.setText("");
        Cantidad.setText("");
        guardarServicios(productos);
        cargarProductos();
        crearBotonesProductos();
        panelProductos.revalidate();
        panelProductos.repaint();
        
        
        
    }//GEN-LAST:event_BtnModificarActionPerformed
    /**
     * Maneja la acción del botón de eliminación de producto.
     * Muestra una confirmación y, si se confirma, elimina el producto seleccionado de la lista de productos.
     * Vacia los campos de texto después de la eliminación y actualiza la interfaz gráfica.
     *
     * @param evt Evento de acción del botón de eliminación.
     */
    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed
        // TODO add your handling code here:
        panelProductos.removeAll();
        int respuesta = JOptionPane.showConfirmDialog(null, "estas seguro de eliminar el producto?", "Confirmación", JOptionPane.YES_NO_OPTION);
        String txtBuscar = Buscar.getText();
        int indexProducto = estaElProducto(txtBuscar);
        if (respuesta == JOptionPane.YES_OPTION){
            productos.remove(indexProducto);
            guardarServicios(productos);
            cargarProductos();
        }
        Nombre.setText("");
        Marca.setText("");
        Precio.setText("");
        Cantidad.setText("");
        crearBotonesProductos();
        guardarServicios(productos);
        cargarProductos();
        panelProductos.revalidate();
        panelProductos.repaint();
    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Pantalla_Principal p = new Pantalla_Principal();
        p.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ProductoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ProductoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ProductoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ProductoGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProductoGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBuscar;
    private javax.swing.JButton BtnCrear;
    private javax.swing.JButton BtnEliminar;
    private javax.swing.JButton BtnModificar;
    private javax.swing.JTextField Buscar;
    private javax.swing.JTextField Cantidad;
    private javax.swing.JTextField Marca;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField Precio;
    private javax.swing.JComboBox<String> Tamaño;
    private javax.swing.JComboBox<String> TipoProducto;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelProductos;
    // End of variables declaration//GEN-END:variables
}
