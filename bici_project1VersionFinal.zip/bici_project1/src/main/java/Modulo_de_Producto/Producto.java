package Modulo_de_Producto;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Clase que representa un producto en el sistema.
 * Contiene información como código, nombre, tipo, tamaño, marca, precio y cantidad.
 * Proporciona métodos para gestionar operaciones relacionadas con productos, como búsqueda, agregado,
 * modificación y eliminación.
 */
public class Producto {

    private int codigo; // Código único del producto.
    private int codigoDelArticulo; // Código del artículo asociado al producto.
    private String nombre; // Nombre del producto.
    private String tipo; // Tipo del producto.
    private String tamaño; // Tamaño del producto.
    private String marca; // Marca del producto.
    private int precio; // Precio del producto.
    private int cantidad; // Cantidad disponible del producto.

    /**
     * Constructor por defecto de la clase Producto.
     * Inicializa los atributos con valores predeterminados.
     */
    public Producto() {
        codigo = 1;
        codigoDelArticulo = 1;
        nombre = "";
        tipo = "";
        tamaño = "";
        marca = "";
        precio = 1;
        cantidad = 1;
    }
    
    
    
/**
 * Método para obtener el código del producto.
 * @return El código único del producto.
 */
public int getCodigo() {
    return codigo;
}

/**
 * Método para establecer el código del producto.
 * @param codigo El nuevo código a asignar al producto.
 */
public void setCodigo(int codigo) {
    this.codigo = codigo;
}

/**
 * Método para obtener el código del artículo asociado al producto.
 * @return El código del artículo asociado al producto.
 */
public int getCodigoDelArticulo() {
    return codigoDelArticulo;
}

/**
 * Método para establecer el código del artículo asociado al producto.
 * @param codigoDelArticulo El nuevo código del artículo a asignar al producto.
 */
public void setCodigoDelArticulo(int codigoDelArticulo) {
    this.codigoDelArticulo = codigoDelArticulo;
}

/**
 * Método para obtener el nombre del producto.
 * @return El nombre del producto.
 */
public String getNombre() {
    return nombre;
}

/**
 * Método para establecer el nombre del producto.
 * @param nombre El nuevo nombre a asignar al producto.
 */
public void setNombre(String nombre) {
    this.nombre = nombre;
}

/**
 * Método para obtener el tipo del producto.
 * @return El tipo del producto.
 */
public String getTipo() {
    return tipo;
}

/**
 * Método para establecer el tipo del producto.
 * @param tipo El nuevo tipo a asignar al producto.
 */
public void setTipo(String tipo) {
    this.tipo = tipo;
}

/**
 * Método para obtener el tamaño del producto.
 * @return El tamaño del producto.
 */
public String getTamaño() {
    return tamaño;
}

/**
 * Método para establecer el tamaño del producto.
 * @param tamanio El nuevo tamaño a asignar al producto.
 */
public void setTamaño(String tamanio) {
    this.tamaño = tamanio;
}

/**
 * Método para obtener la marca del producto.
 * @return La marca del producto.
 */
public String getMarca() {
    return marca;
}

/**
 * Método para establecer la marca del producto.
 * @param marca La nueva marca a asignar al producto.
 */
public void setMarca(String marca) {
    this.marca = marca;
}

/**
 * Método para obtener el precio del producto.
 * @return El precio del producto.
 */
public int getPrecio() {
    return precio;
}

/**
 * Método para establecer el precio del producto.
 * @param precio El nuevo precio a asignar al producto.
 */
public void setPrecio(int precio) {
    this.precio = precio;
}

/**
 * Método para obtener la cantidad disponible del producto.
 * @return La cantidad disponible del producto.
 */
public int getCantidad() {
    return cantidad;
}

/**
 * Método para establecer la cantidad disponible del producto.
 * @param cantidad La nueva cantidad a asignar al producto.
 */
public void setCantidad(int cantidad) {
    this.cantidad = cantidad;
}

//Getters and Setters
    
    public void buscar() {
        // código de búsqueda
    }

    public void agregar() {
        // código para agregar
    }

    public void modificar() {
        // código para modificar
    }

    public void eliminar() {
        // código para eliminar
    }

}
